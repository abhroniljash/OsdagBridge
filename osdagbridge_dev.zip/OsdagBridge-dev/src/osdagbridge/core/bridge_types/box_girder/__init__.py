"""box_girder module."""

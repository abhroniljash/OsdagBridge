"""truss DTO (stub)."""

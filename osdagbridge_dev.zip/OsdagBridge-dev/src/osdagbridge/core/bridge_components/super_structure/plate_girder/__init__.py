"""Girder component package."""

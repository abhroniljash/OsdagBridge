"""Crash barrier package."""

"""Deck properties stub."""

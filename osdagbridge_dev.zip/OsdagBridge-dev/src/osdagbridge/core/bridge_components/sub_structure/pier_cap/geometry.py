"""Pier cap geometry stub."""
